# 📦 ZIP Telegram Bot

Foydalanuvchi bir nechta fayl yuborganda, hammasini bitta ZIP faylga birlashtirib qaytaradigan Telegram bot.

## 🚀 O'rnatish

1. **Bot token olish:** Telegramda [@BotFather](https://t.me/BotFather) ga `/newbot` yuboring va tokenni oling.

2. **Tokenni sozlash:** `index.js` faylida `TOKENNI_SHU_YERGA_QOYING` ni o'z tokeningiz bilan almashtiring:
   ```js
   const BOT_TOKEN = "123456789:ABCdefGHIjklMNOpqrSTUvwxYZ";
   ```
   Yoki muhit o'zgaruvchisi orqali:
   ```bash
   set BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrSTUvwxYZ
   ```

3. **Botni ishga tushirish:**
   ```bash
   node index.js
   ```

## 📌 Buyruqlar

| Buyruq | Tavsif |
|--------|--------|
| `/start` | Botni boshlash |
| `/zip` | Yuborilgan fayllarni ZIP qilish |
| `/cancel` | Sessiyani bekor qilish |
| `/help` | Yordam |

## 🔄 Ishlash tartibi

1. Botga fayllar (hujjat, rasm, video, audio) yuboring
2. `/zip` buyruq yuboring
3. Bot hammasini bitta `fayllar.zip` faylga jamlaydi va qaytaradi

## 📁 Qo'llab-quvvatlanadigan fayllar

- 📄 Hujjatlar (document)
- 🖼 Rasmlar (photo)
- 🎥 Videolar (video)
- 🎵 Audio fayllar (audio)

## ⚠️ Eslatma

Telegram API orqali yuklab olinadigan fayllar hajmi **20 MB** gacha cheklangan.
