// Webhook o'rnatish skripti
// Ishlatish: BOT_TOKEN=... VERCEL_URL=... node set-webhook.js

const BOT_TOKEN = process.env.BOT_TOKEN;
const VERCEL_URL = process.env.VERCEL_URL;

if (!BOT_TOKEN || !VERCEL_URL) {
  console.log("Ishlatish:");
  console.log('  set BOT_TOKEN=9117706545:AAHkZWEuEkGRBOTQxwoT13RA14JRdMMzTxo');
  console.log('  set VERCEL_URL=sizning-loyiha.vercel.app');
  console.log("  node set-webhook.js");
  process.exit(1);
}

const webhookUrl = `https://${VERCEL_URL}/api/webhook`;

fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook?url=${webhookUrl}`)
  .then((r) => r.json())
  .then((data) => {
    if (data.ok) {
      console.log(`✅ Webhook muvaffaqiyatli o'rnatildi!`);
      console.log(`🔗 URL: ${webhookUrl}`);
    } else {
      console.error("❌ Xato:", data.description);
    }
  })
  .catch((err) => console.error("❌ Xato:", err.message));
