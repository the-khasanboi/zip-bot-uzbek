const { Bot, InputFile } = require("node-telegram-bot-api");
const archiver = require("archiver");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

const BOT_TOKEN = process.env.BOT_TOKEN;
const bot = new Bot(BOT_TOKEN);

// /tmp papkada sessiyalarni saqlash (Vercel serverless)
const SESSION_FILE = path.join("/tmp", "sessions.json");

function loadSessions() {
  try {
    if (fs.existsSync(SESSION_FILE)) {
      return new Map(JSON.parse(fs.readFileSync(SESSION_FILE, "utf-8")));
    }
  } catch (_) {}
  return new Map();
}

function saveSessions(sessions) {
  fs.writeFileSync(SESSION_FILE, JSON.stringify([...sessions]), "utf-8");
}

// Fayl yuklab olish
async function downloadTelegramFile(fileId, destPath) {
  const file = await bot.api.getFile(fileId);
  const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
  const response = await axios({ url: fileUrl, method: "GET", responseType: "stream" });
  const writer = fs.createWriteStream(destPath);
  response.data.pipe(writer);
  return new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
  });
}

// Faylni sessiyaga qo'shish
function addFileToSession(chatId, fileId, fileName) {
  const sessions = loadSessions();
  const session = sessions.get(chatId) || { files: [] };
  session.files.push({ fileId, fileName });
  sessions.set(chatId, session);
  saveSessions(sessions);
  return session;
}

// Buyruqlar
bot.command("start", (ctx) => {
  ctx.reply(
    "👋 Salom! Men ZIP Bot!\n\n" +
      "📁 Menga fayllar yuboring — men ularni bitta ZIP faylga jamlayman.\n\n" +
      "📌 Foydalanish:\n" +
      "1. Fayllarni birin-ketin yuboring\n" +
      "2. /zip buyruq yuboring\n" +
      "3. Men hammasini bitta ZIP faylda qaytaraman!\n\n" +
      "🗑 /cancel — sessiyani tozalash"
  );
});

bot.command("help", (ctx) => {
  ctx.reply(
    "📖 Buyruqlar:\n\n" +
      "/start — Botni boshlash\n" +
      "/zip — Fayllarni ZIP qilish\n" +
      "/cancel — Sessiyani tozalash\n" +
      "/help — Yordam"
  );
});

bot.command("cancel", (ctx) => {
  const sessions = loadSessions();
  sessions.delete(ctx.chat.id);
  saveSessions(sessions);
  ctx.reply("🗑 Sessiya tozalandi.");
});

bot.command("zip", async (ctx) => {
  const chatId = ctx.chat.id;
  const sessions = loadSessions();
  const session = sessions.get(chatId);

  if (!session || session.files.length === 0) {
    return ctx.reply("❌ Fayl topilmadi! Avval fayllar yuboring, so'ng /zip bosing.");
  }

  await ctx.reply(`⏳ ${session.files.length} ta fayl ZIP qilinmoqda...`);

  const sessionDir = path.join("/tmp", `zip_${chatId}_${Date.now()}`);
  fs.mkdirSync(sessionDir, { recursive: true });
  const zipPath = path.join(sessionDir, "fayllar.zip");

  try {
    const downloadedFiles = [];
    for (const file of session.files) {
      try {
        const filePath = path.join(sessionDir, file.fileName);
        await downloadTelegramFile(file.fileId, filePath);
        downloadedFiles.push({ name: file.fileName, path: filePath });
      } catch (err) {
        console.error(`Yuklab olishda xato (${file.fileName}):`, err.message);
      }
    }

    if (downloadedFiles.length === 0) {
      throw new Error("Hech qanday fayl yuklab olinmadi");
    }

    // ZIP yaratish
    await new Promise((resolve, reject) => {
      const output = fs.createWriteStream(zipPath);
      const archive = archiver("zip", { zlib: { level: 9 } });
      output.on("close", resolve);
      archive.on("error", reject);
      archive.pipe(output);
      for (const f of downloadedFiles) {
        archive.file(f.path, { name: f.name });
      }
      archive.finalize();
    });

    // ZIP yuborish
    await bot.api.sendDocument(
      chatId,
      new InputFile(fs.createReadStream(zipPath), "fayllar.zip"),
      { caption: `📦 Tayyor! ${downloadedFiles.length} ta fayl ZIP qilindi.` }
    );

    // Tozalash
    sessions.delete(chatId);
    saveSessions(sessions);
    fs.rmSync(sessionDir, { recursive: true, force: true });
  } catch (err) {
    console.error("ZIP xato:", err);
    ctx.reply("❌ ZIP yaratishda xatolik. Qaytadan urinib ko'ring.");
    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true });
    }
  }
});

// Hujjat
bot.on("message:document", (ctx) => {
  const doc = ctx.message.document;
  const session = addFileToSession(ctx.chat.id, doc.file_id, doc.file_name || `file_${Date.now()}`);
  ctx.reply(`✅ Fayl: ${doc.file_name}\n📦 Jami: ${session.files.length}\n\nYana yuboring yoki /zip bosing.`);
});

// Rasm
bot.on("message:photo", (ctx) => {
  const photos = ctx.message.photo;
  const photo = photos[photos.length - 1];
  const sessions = loadSessions();
  const existing = sessions.get(ctx.chat.id) || { files: [] };
  const name = `rasm_${existing.files.length + 1}.jpg`;
  const session = addFileToSession(ctx.chat.id, photo.file_id, name);
  ctx.reply(`✅ Rasm: ${name}\n📦 Jami: ${session.files.length}\n\nYana yuboring yoki /zip bosing.`);
});

// Video
bot.on("message:video", (ctx) => {
  const video = ctx.message.video;
  const name = video.file_name || `video_${Date.now()}.mp4`;
  const session = addFileToSession(ctx.chat.id, video.file_id, name);
  ctx.reply(`✅ Video: ${name}\n📦 Jami: ${session.files.length}\n\nYana yuboring yoki /zip bosing.`);
});

// Audio
bot.on("message:audio", (ctx) => {
  const audio = ctx.message.audio;
  const name = audio.file_name || `audio_${Date.now()}.mp3`;
  const session = addFileToSession(ctx.chat.id, audio.file_id, name);
  ctx.reply(`✅ Audio: ${name}\n📦 Jami: ${session.files.length}\n\nYana yuboring yoki /zip bosing.`);
});

bot.catch((err) => {
  console.error("Bot xatosi:", err);
});

// Vercel webhook handler
module.exports = async (req, res) => {
  try {
    if (req.method === "POST") {
      await bot.init();
      await bot.handleUpdate(req.body);
      res.status(200).json({ ok: true });
    } else {
      res.status(200).json({ status: "ZIP Bot ishlayapti ✅" });
    }
  } catch (err) {
    console.error("Webhook xato:", err);
    res.status(200).json({ ok: true });
  }
};
